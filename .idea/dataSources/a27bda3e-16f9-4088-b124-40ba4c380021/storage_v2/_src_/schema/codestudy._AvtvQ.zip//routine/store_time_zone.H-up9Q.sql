create procedure store_time_zone()
  IF (POSITION('aws_rds@' IN CURRENT_USER()) = 1) THEN
     SET SESSION time_zone = 'Asia/Chongqing';
     END IF;

